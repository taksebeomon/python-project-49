### Hexlet tests and linter status:
[![Actions Status](https://github.com/taksebeomon/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/taksebeomon/python-project-49/actions)

Asciinema with package installation and "brain-even" game test: https://asciinema.org/a/BfcOmeLWPk2xMKdPazjjWVYaD

Asciinema with "brain-calc" game test: https://asciinema.org/a/xQsyNOOZO9jnX7kZIqcFBxoYA

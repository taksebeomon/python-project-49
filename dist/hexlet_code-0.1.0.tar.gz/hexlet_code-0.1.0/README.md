### Hexlet tests and linter status:
[![Actions Status](https://github.com/taksebeomon/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/taksebeomon/python-project-49/actions)

Asciinema with package installation and "brain-even" game test: https://asciinema.org/a/BfcOmeLWPk2xMKdPazjjWVYaD

Asciinema with "brain-calc" game test: https://asciinema.org/a/xQsyNOOZO9jnX7kZIqcFBxoYA

Asciinema with "brain-gcd" game test: https://asciinema.org/a/8RmLmNgb922G8ub95TH7JmnTQ

Asciinema with "brain-progression" game test: https://asciinema.org/a/M8mzBGnjEOEBZmbRolVOx7CWM

Asciinema with "brain-prime" game test: https://asciinema.org/a/nX1TsOkrAd8hJwWl6t8TII2Bt
